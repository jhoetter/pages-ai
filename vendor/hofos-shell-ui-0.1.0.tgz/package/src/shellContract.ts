import type { HofShellAppLink } from "./types";

export const HOF_SHELL_SIDEBAR_DEFAULT_WIDTH = 240;
export const HOF_SHELL_SIDEBAR_MIN_WIDTH = 140;
export const HOF_SHELL_SIDEBAR_MAX_WIDTH = 480;

export const HOF_SHELL_STORAGE_KEYS = {
  sidebarWidth: "hof-shell-sidebar-width",
  sidebarCollapsed: "hof-shell-sidebar-collapsed",
  legacySidebarWidth: "hof-sidebar-width",
  legacySidebarCollapsed: "hof-sidebar-collapsed",
} as const;

export const HOF_SHELL_SIDEBAR_CHANGED_EVENT = "hof:shell-sidebar-changed";

export const HOF_SHELL_ZONE_HEIGHTS = {
  top: 92,
  appLauncher: 188,
  userFooter: 44,
} as const;

export const HOF_SHELL_APP_LINKS: HofShellAppLink[] = [
  { id: "os", label: "App", href: "http://localhost:3000/", icon: "home", order: 10 },
  {
    id: "hofos",
    label: "hofOS",
    href: "http://localhost:3000/__subapps/hofos/customers",
    icon: "briefcase-business",
    authMode: "inherit",
    order: 20,
  },
  {
    id: "mailai",
    label: "Mail",
    href: "http://localhost:3000/__subapps/mailai/inbox",
    icon: "mail",
    authMode: "inherit",
    order: 30,
  },
  {
    id: "collabai",
    label: "Chat",
    href: "http://localhost:3000/__subapps/collabai/",
    icon: "message-circle",
    authMode: "inherit",
    order: 40,
  },
  {
    id: "driveai",
    label: "Drive",
    href: "http://localhost:3000/__subapps/driveai/drive/home",
    icon: "folder",
    authMode: "inherit",
    order: 50,
  },
  {
    id: "pagesai",
    label: "Pages",
    href: "http://localhost:3000/__subapps/pagesai/pages",
    icon: "file-text",
    authMode: "inherit",
    order: 60,
  },
];

export function withSelfAppHref(appId: HofShellAppLink["id"], selfHref: string): HofShellAppLink[] {
  return HOF_SHELL_APP_LINKS.map((link) =>
    link.id === appId ? { ...link, href: selfHref } : link,
  );
}
