import type { HofShellUser } from "./types";

export interface HofShellSessionUser {
  id?: string | null;
  userId?: string | null;
  actorId?: string | null;
  sub?: string | null;
  tenantId?: string | null;
  tid?: string | null;
  email?: string | null;
  name?: string | null;
  displayName?: string | null;
  display_name?: string | null;
  subtitle?: string | null;
}

export interface FetchHofShellUserOptions {
  endpoint?: string;
  fallbackName?: string;
  fallbackInitials?: string;
}

function text(value: unknown): string | undefined {
  return typeof value === "string" && value.trim() ? value.trim() : undefined;
}

function initialsFrom(source: string): string {
  return source
    .split(/[\s@._-]+/)
    .filter(Boolean)
    .map((part) => part[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

export function normalizeHofShellUser(
  raw: HofShellSessionUser | null | undefined,
  options: Pick<FetchHofShellUserOptions, "fallbackName" | "fallbackInitials"> = {},
): HofShellUser | null {
  const name =
    text(raw?.displayName) ??
    text(raw?.display_name) ??
    text(raw?.name) ??
    text(raw?.email) ??
    text(options.fallbackName);
  if (!name) return null;

  const email = text(raw?.email);
  const subtitle = text(raw?.subtitle);
  return {
    name,
    ...(email ? { email } : {}),
    initials: options.fallbackInitials ?? initialsFrom(name),
    ...(subtitle ? { subtitle } : {}),
  };
}

export async function fetchHofShellUser(
  options: FetchHofShellUserOptions = {},
): Promise<HofShellUser | null> {
  const endpoint = options.endpoint ?? "/api/me";
  const response = await fetch(endpoint, {
    credentials: "include",
    headers: { Accept: "application/json" },
  });
  if (!response.ok) return null;
  const payload = (await response.json().catch(() => null)) as
    | HofShellSessionUser
    | { user?: HofShellSessionUser }
    | null;
  let raw: HofShellSessionUser | null | undefined;
  if (payload && typeof payload === "object" && "user" in payload) {
    raw = payload.user;
  } else {
    raw = payload as HofShellSessionUser | null;
  }
  return normalizeHofShellUser(raw, options);
}
