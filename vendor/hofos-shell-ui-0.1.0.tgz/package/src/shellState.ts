import {
  HOF_SHELL_SIDEBAR_CHANGED_EVENT,
  HOF_SHELL_SIDEBAR_DEFAULT_WIDTH,
  HOF_SHELL_SIDEBAR_MAX_WIDTH,
  HOF_SHELL_SIDEBAR_MIN_WIDTH,
  HOF_SHELL_STORAGE_KEYS,
} from "./shellContract";

function readCookie(key: string): string | null {
  if (typeof document === "undefined") return null;
  const prefix = `${encodeURIComponent(key)}=`;
  const entry = document.cookie
    .split(";")
    .map((part) => part.trim())
    .find((part) => part.startsWith(prefix));
  return entry ? decodeURIComponent(entry.slice(prefix.length)) : null;
}

function candidateCookieDomains(): string[] {
  if (typeof window === "undefined") return [];
  const host = window.location.hostname;
  if (host === "localhost" || /^\d+\.\d+\.\d+\.\d+$/.test(host)) return [];
  const parts = host.split(".").filter(Boolean);
  if (parts.length < 2) return [];
  return [`.${parts.slice(-2).join(".")}`];
}

function writeCookie(key: string, value: string): void {
  if (typeof document === "undefined") return;
  const cookie = `${encodeURIComponent(key)}=${encodeURIComponent(value)}; path=/; max-age=31536000; SameSite=Lax`;
  document.cookie = cookie;
  for (const domain of candidateCookieDomains()) {
    document.cookie = `${cookie}; domain=${domain}`;
  }
}

export function readShellStorage(key: string, legacyKey?: string): string | null {
  try {
    return (
      readCookie(key) ??
      (legacyKey ? readCookie(legacyKey) : null) ??
      localStorage.getItem(key) ??
      (legacyKey ? localStorage.getItem(legacyKey) : null)
    );
  } catch {
    return null;
  }
}

export function writeShellStorage(key: string, value: string, legacyKey?: string): void {
  try {
    localStorage.setItem(key, value);
    if (legacyKey) localStorage.setItem(legacyKey, value);
    writeCookie(key, value);
    if (legacyKey) writeCookie(legacyKey, value);
    window.dispatchEvent(new CustomEvent(HOF_SHELL_SIDEBAR_CHANGED_EVENT));
  } catch {}
}

export function readSidebarCollapsed(): boolean {
  return (
    readShellStorage(
      HOF_SHELL_STORAGE_KEYS.sidebarCollapsed,
      HOF_SHELL_STORAGE_KEYS.legacySidebarCollapsed,
    ) === "true"
  );
}

export function readSidebarWidth(): number {
  if (readSidebarCollapsed()) return 0;
  const stored = readShellStorage(
    HOF_SHELL_STORAGE_KEYS.sidebarWidth,
    HOF_SHELL_STORAGE_KEYS.legacySidebarWidth,
  );
  const parsed = stored ? Number(stored) : NaN;
  return Number.isFinite(parsed) &&
    parsed >= HOF_SHELL_SIDEBAR_MIN_WIDTH &&
    parsed <= HOF_SHELL_SIDEBAR_MAX_WIDTH
    ? parsed
    : HOF_SHELL_SIDEBAR_DEFAULT_WIDTH;
}

export function persistSidebarState(width: number, collapsed: boolean): void {
  const persistWidth =
    width >= HOF_SHELL_SIDEBAR_MIN_WIDTH ? width : HOF_SHELL_SIDEBAR_DEFAULT_WIDTH;
  writeShellStorage(
    HOF_SHELL_STORAGE_KEYS.sidebarCollapsed,
    String(collapsed),
    HOF_SHELL_STORAGE_KEYS.legacySidebarCollapsed,
  );
  writeShellStorage(
    HOF_SHELL_STORAGE_KEYS.sidebarWidth,
    String(persistWidth),
    HOF_SHELL_STORAGE_KEYS.legacySidebarWidth,
  );
}

export function isSidebarStorageKey(key: string | null): boolean {
  return (
    key === HOF_SHELL_STORAGE_KEYS.sidebarWidth ||
    key === HOF_SHELL_STORAGE_KEYS.legacySidebarWidth ||
    key === HOF_SHELL_STORAGE_KEYS.sidebarCollapsed ||
    key === HOF_SHELL_STORAGE_KEYS.legacySidebarCollapsed
  );
}
