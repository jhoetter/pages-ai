import type { ReactNode } from "react";

export type HofShellAuthMode = "inherit" | "own" | "none";
export type HofShellAppId = "os" | "hofos" | "mailai" | "collabai" | "driveai" | "pagesai";
export type HofColorScheme = "light" | "dark" | "system";

export interface HofShellNavItem {
  id?: string;
  label: string;
  path?: string;
  href?: string;
  icon?: string;
  active?: boolean;
  activePaths?: string[];
  authMode?: HofShellAuthMode;
  badge?: number | string;
  hint?: string;
  disabled?: boolean;
  onSelect?: () => void;
  content?: ReactNode;
}

export interface HofShellNavGroup {
  id: string;
  label?: string;
  items: HofShellNavItem[];
  action?: {
    label: string;
    icon?: string;
    onSelect: () => void;
  };
}

export interface HofShellAppLink {
  id: HofShellAppId;
  label: string;
  href: string;
  icon: string;
  authMode?: HofShellAuthMode;
  order: number;
}

export interface HofShellUser {
  name: string;
  email?: string;
  initials?: string;
  subtitle?: string;
}

export interface HofShellUserMenuItem {
  id: string;
  label: string;
  icon?: string;
  onSelect?: () => void;
}
