import type { HofColorScheme } from "./types";

export const HOF_COLOR_SCHEME_STORAGE_KEY = "hof-color-scheme";

const VALID: ReadonlySet<string> = new Set(["light", "dark", "system"]);
const LIGHT = "hof-theme-light";
const DARK = "hof-theme-dark";

function readCookie(key: string): string | null {
  if (typeof document === "undefined") return null;
  const prefix = `${encodeURIComponent(key)}=`;
  const entry = document.cookie
    .split(";")
    .map((part) => part.trim())
    .find((part) => part.startsWith(prefix));
  return entry ? decodeURIComponent(entry.slice(prefix.length)) : null;
}

function writeCookie(key: string, value: string): void {
  if (typeof document === "undefined") return;
  const cookie = `${encodeURIComponent(key)}=${encodeURIComponent(value)}; path=/; max-age=31536000; SameSite=Lax`;
  document.cookie = cookie;
  if (typeof window === "undefined") return;
  const host = window.location.hostname;
  if (host === "localhost" || /^\d+\.\d+\.\d+\.\d+$/.test(host)) return;
  const parts = host.split(".").filter(Boolean);
  if (parts.length >= 2) {
    document.cookie = `${cookie}; domain=.${parts.slice(-2).join(".")}`;
  }
}

export function getStoredColorScheme(): HofColorScheme {
  try {
    const raw =
      readCookie(HOF_COLOR_SCHEME_STORAGE_KEY) ??
      localStorage.getItem(HOF_COLOR_SCHEME_STORAGE_KEY);
    if (raw && VALID.has(raw)) return raw as HofColorScheme;
  } catch {}
  return "system";
}

export function setStoredColorScheme(scheme: HofColorScheme): void {
  try {
    localStorage.setItem(HOF_COLOR_SCHEME_STORAGE_KEY, scheme);
    writeCookie(HOF_COLOR_SCHEME_STORAGE_KEY, scheme);
  } catch {}
}

export function applyColorScheme(scheme: HofColorScheme): void {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.classList.remove(LIGHT, DARK);
  root.removeAttribute("data-theme");
  if (scheme === "light") {
    root.classList.add(LIGHT);
    root.dataset.theme = "light";
  } else if (scheme === "dark") {
    root.classList.add(DARK);
    root.dataset.theme = "dark";
  }
}
