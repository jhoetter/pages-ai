import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";
import { applyColorScheme, getStoredColorScheme, setStoredColorScheme } from "./colorScheme";
import { LucideIconByName } from "./LucideIconByName";
import {
  HOF_SHELL_APP_LINKS,
  HOF_SHELL_SIDEBAR_CHANGED_EVENT,
  HOF_SHELL_SIDEBAR_DEFAULT_WIDTH,
  HOF_SHELL_SIDEBAR_MAX_WIDTH,
  HOF_SHELL_SIDEBAR_MIN_WIDTH,
} from "./shellContract";
import {
  isSidebarStorageKey,
  persistSidebarState,
  readSidebarCollapsed,
  readSidebarWidth,
} from "./shellState";
import type {
  HofColorScheme,
  HofShellAppId,
  HofShellAppLink,
  HofShellAuthMode,
  HofShellNavGroup,
  HofShellNavItem,
  HofShellUser,
  HofShellUserMenuItem,
} from "./types";

interface HofShellLayoutProps {
  appId: HofShellAppId;
  appLabel: string;
  appIcon: string;
  currentPath: string;
  children: ReactNode;
  primaryNavGroups: HofShellNavGroup[];
  secondaryNavGroups?: HofShellNavGroup[];
  appLinks?: HofShellAppLink[];
  user?: HofShellUser | null;
  onNavigate?: (path: string, authMode?: HofShellAuthMode) => void;
  onSignOut?: () => void;
  onCommand?: () => void;
  commandLabel?: string;
  commandShortcut?: string;
  commandPaletteSlot?: ReactNode;
  userMenuItems?: HofShellUserMenuItem[];
  topSlot?: ReactNode;
  navSlot?: ReactNode;
  className?: string;
}

interface DragState {
  startX: number;
  startWidth: number;
}

function isExternalPath(path: string): boolean {
  return /^https?:\/\//.test(path);
}

function isActivePath(currentPath: string, item: HofShellNavItem): boolean {
  if (item.active !== undefined) return item.active;
  const path = item.path ?? item.href;
  if (!path || isExternalPath(path)) return false;
  if (path === "/") return currentPath === "/";
  if (currentPath === path || currentPath.startsWith(`${path}/`)) return true;
  return item.activePaths?.some((active) => currentPath === active || currentPath.startsWith(`${active}/`)) ?? false;
}

function initialsFor(user?: HofShellUser | null, fallback = "U"): string {
  if (user?.initials) return user.initials.toUpperCase().slice(0, 2);
  const source = user?.name || fallback;
  return source
    .split(/\s+/)
    .filter(Boolean)
    .map((part) => part[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

export function HofShellLayout({
  appId,
  appLabel,
  appIcon,
  currentPath,
  children,
  primaryNavGroups,
  secondaryNavGroups = [],
  appLinks = HOF_SHELL_APP_LINKS,
  user,
  onNavigate,
  onSignOut,
  onCommand,
  commandLabel = "Actions",
  commandShortcut = "⌘K",
  commandPaletteSlot,
  userMenuItems = [],
  topSlot,
  navSlot,
  className = "",
}: HofShellLayoutProps): ReactNode {
  const [sidebarWidth, setSidebarWidth] = useState(readSidebarWidth);
  const [collapsed, setCollapsed] = useState(readSidebarCollapsed);
  const [drag, setDrag] = useState<DragState | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const widthBeforeCollapse = useRef(sidebarWidth || HOF_SHELL_SIDEBAR_DEFAULT_WIDTH);

  useLayoutEffect(() => {
    applyColorScheme(getStoredColorScheme());
  }, []);

  useEffect(() => {
    if (!collapsed && sidebarWidth >= HOF_SHELL_SIDEBAR_MIN_WIDTH) {
      widthBeforeCollapse.current = sidebarWidth;
    }
  }, [collapsed, sidebarWidth]);

  useEffect(() => {
    const syncSidebarState = () => {
      const nextCollapsed = readSidebarCollapsed();
      setCollapsed(nextCollapsed);
      setSidebarWidth(nextCollapsed ? 0 : readSidebarWidth());
    };
    const onStorage = (event: StorageEvent) => {
      if (isSidebarStorageKey(event.key)) syncSidebarState();
    };
    window.addEventListener("storage", onStorage);
    window.addEventListener(HOF_SHELL_SIDEBAR_CHANGED_EVENT, syncSidebarState);
    return () => {
      window.removeEventListener("storage", onStorage);
      window.removeEventListener(HOF_SHELL_SIDEBAR_CHANGED_EVENT, syncSidebarState);
    };
  }, []);

  const handleNavigate = useCallback(
    (path: string, authMode?: HofShellAuthMode) => {
      if (onNavigate) onNavigate(path, authMode);
      else window.location.href = path;
      setMobileOpen(false);
    },
    [onNavigate],
  );

  const handleResizeStart = useCallback(
    (event: React.MouseEvent) => {
      event.preventDefault();
      setDrag({
        startX: event.clientX,
        startWidth: sidebarWidth || widthBeforeCollapse.current,
      });
    },
    [sidebarWidth],
  );

  useEffect(() => {
    if (!drag) return;
    const onMouseMove = (event: MouseEvent) => {
      const next = Math.max(0, Math.min(drag.startWidth + event.clientX - drag.startX, HOF_SHELL_SIDEBAR_MAX_WIDTH));
      if (next < HOF_SHELL_SIDEBAR_MIN_WIDTH) {
        setCollapsed(true);
        setSidebarWidth(0);
      } else {
        setCollapsed(false);
        setSidebarWidth(next);
      }
    };
    const onMouseUp = () => {
      const nextCollapsed = sidebarWidth < HOF_SHELL_SIDEBAR_MIN_WIDTH;
      persistSidebarState(nextCollapsed ? widthBeforeCollapse.current : sidebarWidth, nextCollapsed);
      setCollapsed(nextCollapsed);
      if (nextCollapsed) setSidebarWidth(0);
      setDrag(null);
    };
    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);
    return () => {
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
    };
  }, [drag, sidebarWidth]);

  const effectiveWidth = collapsed && !drag ? 0 : sidebarWidth;
  const isDragging = drag !== null;

  return (
    <div
      className={`hof-shell ${className}${isDragging ? " hof-shell--dragging" : ""}`}
      data-hof-shell="true"
      data-hof-shell-app={appId}
    >
      <button
        type="button"
        className="hof-shell-mobile-toggle"
        onClick={() => setMobileOpen(true)}
        aria-label="Open navigation"
      >
        <LucideIconByName name={appIcon} size={16} />
      </button>
      {mobileOpen ? (
        <button
          type="button"
          className="hof-shell-overlay"
          onClick={() => setMobileOpen(false)}
          aria-label="Close navigation"
        />
      ) : null}
      <div
        className="hof-shell-sidebar-wrap"
        style={{ width: effectiveWidth }}
        data-hof-sidebar-width={Math.round(effectiveWidth)}
      >
        <HofSidebar
          appId={appId}
          appLabel={appLabel}
          appIcon={appIcon}
          currentPath={currentPath}
          collapsed={effectiveWidth === 0}
          mobileOpen={mobileOpen}
          primaryNavGroups={primaryNavGroups}
          secondaryNavGroups={secondaryNavGroups}
          appLinks={appLinks}
          user={user}
          userMenuItems={userMenuItems}
          onNavigate={handleNavigate}
          onSignOut={onSignOut}
          onCommand={onCommand}
          commandLabel={commandLabel}
          commandShortcut={commandShortcut}
          topSlot={topSlot}
          navSlot={navSlot}
        />
        <div
          className="hof-shell-resize-handle"
          onMouseDown={handleResizeStart}
          role="separator"
          aria-orientation="vertical"
          aria-label="Resize sidebar"
        />
      </div>
      <main className="hof-shell-main" style={{ ["--hof-sidebar-width" as string]: `${effectiveWidth}px` }}>
        {children}
      </main>
      {commandPaletteSlot}
    </div>
  );
}

function HofSidebar({
  appId,
  appLabel,
  appIcon,
  currentPath,
  collapsed,
  mobileOpen,
  primaryNavGroups,
  secondaryNavGroups = [],
  appLinks = HOF_SHELL_APP_LINKS,
  user,
  userMenuItems = [],
  onNavigate,
  onSignOut,
  onCommand,
  commandLabel,
  commandShortcut,
  topSlot,
  navSlot,
}: Omit<HofShellLayoutProps, "children" | "className" | "commandPaletteSlot"> & {
  collapsed: boolean;
  mobileOpen: boolean;
  onNavigate: (path: string, authMode?: HofShellAuthMode) => void;
}): ReactNode {
  const orderedApps = useMemo<HofShellAppLink[]>(
    () => [...appLinks].sort((a, b) => a.order - b.order),
    [appLinks],
  );
  return (
    <aside
      className={`hof-shell-sidebar${collapsed ? " hof-shell-sidebar--collapsed" : ""}${mobileOpen ? " hof-shell-sidebar--open" : ""}`}
      data-hof-sidebar="true"
    >
      <div className="hof-shell-top">
        <div className="hof-shell-brand">
          <LucideIconByName name={appIcon} size={15} />
          {!collapsed ? <span>{appLabel}</span> : null}
        </div>
        {!collapsed && onCommand ? (
          <button type="button" className="hof-shell-command" onClick={onCommand}>
            <span>{commandLabel}</span>
            <span>{commandShortcut}</span>
          </button>
        ) : null}
        {!collapsed ? topSlot : null}
      </div>

      <div className="hof-shell-nav">
        {navSlot ??
          [...primaryNavGroups, ...secondaryNavGroups].map((group) => (
            <HofSidebarSection
              key={group.id}
              group={group}
              currentPath={currentPath}
              collapsed={collapsed}
              onNavigate={onNavigate}
            />
          ))}
      </div>

      {!collapsed ? (
        <div className="hof-shell-apps" data-hof-app-launcher="true">
          <div className="hof-shell-section-label">Apps</div>
          <div className="hof-shell-section-items">
            {orderedApps.map((link) => (
              <HofSidebarItem
                key={link.id}
                item={{
                  id: link.id,
                  label: link.label,
                  href: link.href,
                  icon: link.icon,
                  active: link.id === appId,
                  authMode: link.authMode,
                }}
                currentPath={currentPath}
                collapsed={false}
                onNavigate={onNavigate}
              />
            ))}
          </div>
        </div>
      ) : null}

      <div className="hof-shell-user-region">
        <HofUserMenu user={user} fallbackLabel={`${appLabel} user`} items={userMenuItems} onSignOut={onSignOut} />
      </div>
    </aside>
  );
}

function HofSidebarSection({
  group,
  currentPath,
  collapsed,
  onNavigate,
}: {
  group: HofShellNavGroup;
  currentPath: string;
  collapsed: boolean;
  onNavigate: (path: string, authMode?: HofShellAuthMode) => void;
}) {
  if (group.items.length === 0 && !group.action) return null;
  return (
    <section className="hof-shell-section" data-hof-sidebar-section={group.id}>
      {!collapsed && group.label ? (
        <div className="hof-shell-section-heading">
          <span>{group.label}</span>
          {group.action ? (
            <button
              type="button"
              className="hof-shell-section-action"
              onClick={group.action.onSelect}
              aria-label={group.action.label}
              title={group.action.label}
            >
              <LucideIconByName name={group.action.icon || "plus"} size={13} />
            </button>
          ) : null}
        </div>
      ) : null}
      <div className="hof-shell-section-items">
        {group.items.map((item, idx) =>
          item.content ? (
            <div key={item.id ?? `${group.id}:${idx}`} className="hof-shell-custom-item">
              {item.content}
            </div>
          ) : (
            <HofSidebarItem
              key={item.id ?? item.path ?? item.href ?? `${group.id}:${idx}`}
              item={item}
              currentPath={currentPath}
              collapsed={collapsed}
              onNavigate={onNavigate}
            />
          ),
        )}
      </div>
    </section>
  );
}

function HofSidebarItem({
  item,
  currentPath,
  collapsed,
  onNavigate,
}: {
  item: HofShellNavItem;
  currentPath: string;
  collapsed: boolean;
  onNavigate: (path: string, authMode?: HofShellAuthMode) => void;
}) {
  const target = item.path ?? item.href ?? "#";
  const active = isActivePath(currentPath, item);
  const content = (
    <>
      <span className="hof-shell-item-icon">
        <LucideIconByName name={item.icon || "circle"} size={14} />
      </span>
      {!collapsed ? <span className="hof-shell-item-label">{item.label}</span> : null}
      {!collapsed && item.hint ? <span className="hof-shell-item-hint">{item.hint}</span> : null}
      {!collapsed && item.badge !== undefined ? <span className="hof-shell-item-badge">{item.badge}</span> : null}
    </>
  );
  if (item.disabled) {
    return (
      <div className="hof-shell-item hof-shell-item--disabled" aria-disabled>
        {content}
      </div>
    );
  }
  return (
    <button
      type="button"
      className={`hof-shell-item${active ? " hof-shell-item--active" : ""}`}
      aria-current={active ? "page" : undefined}
      title={collapsed ? item.label : undefined}
      onClick={() => {
        item.onSelect?.();
        if (target !== "#") onNavigate(target, item.authMode);
      }}
    >
      {content}
    </button>
  );
}

function HofUserMenu({
  user,
  fallbackLabel,
  items,
  onSignOut,
}: {
  user?: HofShellUser | null;
  fallbackLabel: string;
  items: HofShellUserMenuItem[];
  onSignOut?: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [scheme, setScheme] = useState<HofColorScheme>(getStoredColorScheme);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const displayUser = user ?? { name: fallbackLabel };

  useEffect(() => {
    if (!open) return;
    const onPointer = (event: MouseEvent) => {
      const target = event.target as Node;
      if (triggerRef.current?.contains(target) || menuRef.current?.contains(target)) return;
      setOpen(false);
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onPointer);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onPointer);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const pickScheme = (next: HofColorScheme) => {
    setStoredColorScheme(next);
    applyColorScheme(next);
    setScheme(next);
  };

  return (
    <div className="hof-shell-user-menu">
      <button
        ref={triggerRef}
        type="button"
        className="hof-shell-user-trigger"
        onClick={() => setOpen((value: boolean) => !value)}
        aria-haspopup="menu"
        aria-expanded={open}
      >
        <span className="hof-shell-avatar">{initialsFor(displayUser, fallbackLabel)}</span>
        <span className="hof-shell-user-text">
          <span className="hof-shell-user-name">{displayUser.name}</span>
          {displayUser.subtitle || displayUser.email ? (
            <span className="hof-shell-user-subtitle">{displayUser.subtitle ?? displayUser.email}</span>
          ) : null}
        </span>
      </button>
      {open && typeof document !== "undefined"
        ? createPortal(
            <div ref={menuRef} className="hof-shell-user-popover" role="menu">
              <div className="hof-shell-theme-row" role="group" aria-label="Appearance">
                {(["light", "dark", "system"] as HofColorScheme[]).map((value) => (
                  <button
                    key={value}
                    type="button"
                    className={`hof-shell-theme-button${scheme === value ? " hof-shell-theme-button--active" : ""}`}
                    onClick={() => pickScheme(value)}
                    aria-label={value}
                  >
                    <LucideIconByName name={value === "light" ? "sun" : value === "dark" ? "moon" : "monitor"} size={15} />
                  </button>
                ))}
              </div>
              {items.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  className="hof-shell-menu-item"
                  onClick={() => {
                    item.onSelect();
                    setOpen(false);
                  }}
                >
                  <LucideIconByName name={item.icon || "circle"} size={14} />
                  <span>{item.label}</span>
                </button>
              ))}
              {onSignOut ? (
                <button
                  type="button"
                  className="hof-shell-menu-item"
                  onClick={() => {
                    onSignOut();
                    setOpen(false);
                  }}
                >
                  <LucideIconByName name="log-out" size={14} />
                  <span>Sign out</span>
                </button>
              ) : null}
            </div>,
            document.body,
          )
        : null}
    </div>
  );
}
