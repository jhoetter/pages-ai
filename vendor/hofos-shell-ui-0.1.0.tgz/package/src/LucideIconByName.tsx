import {
  Activity,
  Archive,
  Ban,
  BriefcaseBusiness,
  Calendar,
  CheckCircle2,
  Circle,
  Clock,
  Command,
  File,
  FileText,
  Folder,
  FolderUp,
  HardDrive,
  Home,
  Inbox,
  LayoutGrid,
  List,
  Mail,
  MessageCircle,
  Moon,
  Send,
  Settings,
  Trash2,
  Upload,
  User,
} from "lucide-react";
import dynamicIconImports from "lucide-react/dynamicIconImports";
import { lazy, Suspense, useMemo, type ReactNode } from "react";

type IconComponent = (props: { size?: number; strokeWidth?: number; "aria-hidden"?: boolean }) => ReactNode;
const icon = (component: unknown): IconComponent => component as IconComponent;
const FallbackIcon = icon(Circle);

const ICONS: Partial<Record<string, IconComponent>> = {
  activity: icon(Activity),
  archive: icon(Archive),
  ban: icon(Ban),
  briefcase: icon(BriefcaseBusiness),
  "briefcase-business": icon(BriefcaseBusiness),
  calendar: icon(Calendar),
  "check-circle": icon(CheckCircle2),
  "check-circle-2": icon(CheckCircle2),
  circle: icon(Circle),
  clock: icon(Clock),
  command: icon(Command),
  file: icon(File),
  "file-text": icon(FileText),
  folder: icon(Folder),
  "folder-up": icon(FolderUp),
  "hard-drive": icon(HardDrive),
  home: icon(Home),
  inbox: icon(Inbox),
  "layout-grid": icon(LayoutGrid),
  list: icon(List),
  mail: icon(Mail),
  message: icon(MessageCircle),
  "message-circle": icon(MessageCircle),
  moon: icon(Moon),
  send: icon(Send),
  settings: icon(Settings),
  trash: icon(Trash2),
  "trash-2": icon(Trash2),
  upload: icon(Upload),
  user: icon(User),
};

function toKebabCase(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) return "circle";
  if (trimmed.includes("-") && trimmed === trimmed.toLowerCase()) return trimmed;
  return trimmed
    .replace(/([a-z0-9])([A-Z])/g, "$1-$2")
    .replace(/[\s_]+/g, "-")
    .toLowerCase();
}

export function LucideIconByName({
  name,
  size = 15,
  strokeWidth = 1.8,
}: {
  name?: string;
  size?: number;
  strokeWidth?: number;
}): ReactNode {
  const slug = toKebabCase(name ?? "circle");
  const direct = ICONS[slug];
  const loader =
    direct || !(slug in dynamicIconImports)
      ? null
      : dynamicIconImports[slug as keyof typeof dynamicIconImports];
  const LazyIcon = useMemo(() => {
    if (!loader) return null;
    return lazy(loader as () => Promise<{ default: IconComponent }>);
  }, [loader]);

  if (direct) {
    const Icon = direct;
    return <Icon aria-hidden size={size} strokeWidth={strokeWidth} />;
  }
  if (!LazyIcon) return <FallbackIcon aria-hidden size={size} strokeWidth={strokeWidth} />;
  return (
    <Suspense fallback={<FallbackIcon aria-hidden size={size} strokeWidth={strokeWidth} />}>
      <LazyIcon aria-hidden size={size} strokeWidth={strokeWidth} />
    </Suspense>
  );
}
